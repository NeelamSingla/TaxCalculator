package calculator

type Car struct {
}

func (c Car) getVehicleType() string {
	return "Car"
}
