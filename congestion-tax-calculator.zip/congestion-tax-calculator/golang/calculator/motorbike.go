package calculator

type Motorbike struct {
}

func (m Motorbike) getVehicleType() string {
	return "Motorbike"
}
