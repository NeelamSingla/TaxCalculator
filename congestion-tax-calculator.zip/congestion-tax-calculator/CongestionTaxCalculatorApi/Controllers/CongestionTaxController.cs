using congestion.calculator.Models;
using congestion.calculator.Services;
using Microsoft.AspNetCore.Mvc;

namespace CongestionTaxCalculatorApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CongestionTaxController : ControllerBase
    {
       

        private readonly ILogger<CongestionTaxController> _logger;
        private readonly CongestionTaxCalculatorService _congestionTaxCalculator;
        private readonly Vehicle _vehicle;

        public CongestionTaxController(ILogger<CongestionTaxController> logger, CongestionTaxCalculatorService congestionTaxCalculator, Vehicle vehicle)
        {
            _logger = logger;
            _congestionTaxCalculator = congestionTaxCalculator;
            _vehicle = vehicle;
        }

        [HttpGet(Name = "GetCongestionTaxForVehicle")]
        public int GetCongestionTax([FromQuery]string  VehicleRegistraionNumber , DateTime[] dates)
        {
            var vehicle =_vehicle.GetVehicle(VehicleRegistraionNumber);
            try
            {
                return _congestionTaxCalculator.GetTax(vehicle, dates);
            }
            catch (Exception e)
            {
                _logger.LogError("Request failed for fetching data with Vehicle registration Number",e);

                throw;
            }
        }
    }
}