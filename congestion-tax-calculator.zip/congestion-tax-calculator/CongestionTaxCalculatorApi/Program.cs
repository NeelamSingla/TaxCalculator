using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using congestion.calculator.Models;
using congestion.calculator.Services;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.

        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        builder.Services.Configure<TaxTableConfig>(options =>
        {
            var _keyVaultUri = Environment.GetEnvironmentVariable("keyvaulturi");
            SecretClient kvClient = new SecretClient(new Uri(uriString: _keyVaultUri), new DefaultAzureCredential());
           options.Six_To_Six_twentynine_tax = kvClient.GetSecret("Six_To_Six_twentynine_tax").Value.Value;
            options.Six_thirty_To_Six_fifytnine_tax = kvClient.GetSecret("Six_thirty_To_Six_fifytnine_tax").Value.Value;
            options.Seven_To_Seven_fiftynine_tax = kvClient.GetSecret("Seven_To_Seven_fiftynine_tax").Value.Value;
            options.Eight_To_Eight_twentynine_tax = kvClient.GetSecret("Eight_To_Eight_twentynine_tax").Value.Value;
            options.Halfpasteight_To_Fourteen_fiftynine_tax = kvClient.GetSecret("Halfpasteight_To_Fourteen_fiftynine_tax").Value.Value;
            options.Fifteen_To_Fifteen_twentynine_tax = kvClient.GetSecret("Fifteen_To_Fifteen_twentynine_tax").Value.Value;
            options.Halfpastsfifteen_To_Sixteen_fiftynine_tax = kvClient.GetSecret("Halfpastsfifteen_To_Sixteen_fiftynine_tax").Value.Value;
            options.Seventeen_To_seventten_fiftynine_tax = kvClient.GetSecret("Seven_To_Seven_fiftynine_tax").Value.Value;
            options.Eighteen_To_Eighteen_twentynine_tax = kvClient.GetSecret("Eighteen_To_Eighteen_twentynine_tax").Value.Value;
        });
        builder.Services.AddSingleton<CongestionTaxCalculatorService>();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}