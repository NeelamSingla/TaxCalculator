﻿using congestion.calculator.Models;
using Microsoft.Extensions.Options;
using System;

namespace congestion.calculator.Services
{
    public class CongestionTaxCalculatorService
    {
        private readonly TaxTableConfig _taxTableConfig;
        public CongestionTaxCalculatorService(IOptions<TaxTableConfig> taxTableConfig)
        {
            _taxTableConfig = taxTableConfig.Value;
        }

        public int GetTax(Vehicle vehicle, DateTime[] dates)
        {
            DateTime intervalStart = dates[0];
            int totalFee = 0;
            int firstFee = GetTollFee(intervalStart, vehicle);
            totalFee += firstFee;
            if (dates.Length > 1)
            {
                for (int i = 1; i < dates.Length; i++)
                {

                    int nextFee = GetTollFee(dates[i], vehicle);
                    long diffInMillies = dates[i].Millisecond - intervalStart.Millisecond;
                    long minutes = diffInMillies / 1000 / 60;

                    if (minutes <= 60)
                    {

                        totalFee = nextFee < firstFee ? firstFee : nextFee;
                    }
                    else
                    {
                        totalFee += nextFee;
                    }
                }
            }
            if (totalFee > 60) totalFee = 60;
            return totalFee;
        }

        private bool IsTollFreeVehicle(Vehicle vehicle)
        {
            if (vehicle == null) return false;
            String vehicleType = vehicle.GetVehicleType();
            return vehicleType.Equals(TollFreeVehicles.Motorcycle.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Tractor.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Emergency.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Diplomat.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Foreign.ToString()) ||
                   vehicleType.Equals(TollFreeVehicles.Military.ToString());
        }

        private int GetTollFee(DateTime date, Vehicle vehicle)
        {
            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            int hour = date.Hour;
            int minute = date.Minute;

            if (hour == 6 && minute >= 0 && minute <= 29) return Convert.ToInt32(_taxTableConfig.Six_To_Six_twentynine_tax);
            else if (hour == 6 && minute >= 30 && minute <= 59) return Convert.ToInt32(_taxTableConfig.Six_thirty_To_Six_fifytnine_tax);
            else if (hour == 7 && minute >= 0 && minute <= 59) return Convert.ToInt32(_taxTableConfig.Seven_To_Seven_fiftynine_tax);
            else if (hour == 8 && minute >= 0 && minute <= 29) return Convert.ToInt32(_taxTableConfig.Eight_To_Eight_twentynine_tax);
            else if (hour == 8 &&  minute >= 30 || hour == 14 && minute <= 59) return Convert.ToInt32(_taxTableConfig.Halfpasteight_To_Fourteen_fiftynine_tax);
            else if (hour == 15 && minute >= 0 && minute <= 29) return Convert.ToInt32(_taxTableConfig.Fifteen_To_Fifteen_twentynine_tax);
            else if (hour == 15 && minute >= 30 || hour == 16 && minute <= 59) return Convert.ToInt32(_taxTableConfig.Halfpastsfifteen_To_Sixteen_fiftynine_tax);
            else if (hour == 17 && minute >= 0 && minute <= 59) return Convert.ToInt32(_taxTableConfig.Seventeen_To_seventten_fiftynine_tax);
            else if (hour == 18 && minute >= 0 && minute <= 29) return Convert.ToInt32(_taxTableConfig.Eighteen_To_Eighteen_twentynine_tax);
            else return 0;
        }

        private Boolean IsTollFreeDate(DateTime date)
        {
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            if (year == 2013)
            {
                if ((month == 1 && day == 1) ||
                   (month == 3 && (day == 27 || day == 28 || day == 29)) ||
                    (month == 4 && (day == 1 || day == 30)) ||
                    (month == 5 && (day == 1 || day == 8 || day == 9)) ||
                    (month == 6 && (day == 5 || day == 6 || day == 21)) ||
                   (month == 7) ||
                   (month == 10 && day == 31) ||
                    (month == 11 && day == 1) ||
                   (month == 12 && (day == 23 || day == 24 || day == 25 || day == 26 || day == 31)))
                {
                    return true;
                }
            }
            return false;
        }

        private enum TollFreeVehicles
        {
            Motorcycle = 0,
            Tractor = 1,
            Emergency = 2,
            Diplomat = 3,
            Foreign = 4,
            Military = 5
        }
    }
}
