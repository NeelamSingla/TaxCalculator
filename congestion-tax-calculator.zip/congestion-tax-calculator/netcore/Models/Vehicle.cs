using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace congestion.calculator.Models
{
    public class Vehicle
    {
        private readonly string _vehicleRegistrationNumber;
        public Vehicle(string VehicleRegistrationNumber)
        {
            _vehicleRegistrationNumber = VehicleRegistrationNumber;
        }

        public Vehicle GetVehicle(string VehicleRegistrationNumber)
        {
            // Call Database/api to fetch vehicle data
            return new Vehicle(_vehicleRegistrationNumber);
        }

        public string GetVehicleType()
        {
            // Call Database/api to fetch vehicle data
            return "car";
        }
    }
}