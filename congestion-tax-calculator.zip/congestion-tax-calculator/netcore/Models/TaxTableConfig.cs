﻿namespace congestion.calculator.Models
{
    public class TaxTableConfig
    {
        public string Six_To_Six_twentynine_tax { get; set; }
        public string Six_thirty_To_Six_fifytnine_tax { get; set; }
        public string Seven_To_Seven_fiftynine_tax { get; set; }
        public string Eight_To_Eight_twentynine_tax { get; set; }
        public string Halfpasteight_To_Fourteen_fiftynine_tax { get; set; }
        public string Fifteen_To_Fifteen_twentynine_tax { get; set; }
        public string Halfpastsfifteen_To_Sixteen_fiftynine_tax { get; set; }
        public string Seventeen_To_seventten_fiftynine_tax { get; set; }

        public string Eighteen_To_Eighteen_twentynine_tax { get; set; }
        public string HalfPastEighteen_To_Five_fiftynine_tax { get; set; }

    }

}