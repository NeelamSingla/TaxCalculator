from vehicle import Vehicle


class Car(Vehicle):
    def get_vehicle_type(self) -> str:
        return "Car"
