package congestion.calculator;

import java.util.*;
import java.text.*;

public class Motorbike implements Vehicle {
    @Override
    public String getVehicleType() {
        return "Motorbike";
    }
}
