package congestion.calculator;

import java.util.*;
import java.text.*;

public class Car implements Vehicle {

    public String getVehicleType() {
        return "Car";
    }
}
